'use strict';
/**
 * @name widget1
 * @public
 * @author haiyang5210
 * @date 2014-11-21 00:43
 */
hui.define('widget1', [], function () {
    hui.widget1 = 'WIDGET001';
});