'use strict';
/**
 * @name widget2
 * @public
 * @author haiyang5210
 * @date 2014-11-21 00:49
 */
hui.define('widget2', ['widget1'], function () {
    hui.widget2 = 'WIDGET2';
});