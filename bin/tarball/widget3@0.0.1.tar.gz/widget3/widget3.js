'use strict';
/**
 * @name widget3
 * @public
 * @author haiyang5210
 * @date 2014-11-22 09:34
 */
hui.define('widget3', [], function () {
    
});